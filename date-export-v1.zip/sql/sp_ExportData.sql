CREATE OR ALTER PROCEDURE dba.sp_ExportData
    @StartDate datetime,
    @EndDate datetime = NULL,
    @AnalyzeStructure bit = 1,     -- Re-analyze database structure
    @MaxRelationshipLevel int = 1,  -- Maximum levels of relationships to analyze
    @MinimumRows int = 1000,       -- Minimum rows for transaction consideration
    @ConfidenceThreshold decimal(5,2) = 0.7,  -- Confidence threshold for auto-identification
    @BatchSize int = 10000,        -- Batch size for processing
    @Debug bit = 0                 -- Enable debug output
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @msg nvarchar(max);
    DECLARE @ErrorMsg nvarchar(max);
    DECLARE @ExportID int;
    DECLARE @StartTime datetime = GETDATE();

    BEGIN TRY
        -- Step 1: Analyze database structure if requested
        IF @AnalyzeStructure = 1
        BEGIN
            IF @Debug = 1 RAISERROR('Step 1: Analyzing database structure...', 0, 1) WITH NOWAIT;
            
            EXEC dba.sp_AnalyzeDatabaseStructure 
                @MinimumRows = @MinimumRows,
                @ConfidenceThreshold = @ConfidenceThreshold,
                @Debug = @Debug;

            IF @Debug = 1
            BEGIN
                SELECT @msg = 'Identified transaction tables:' + CHAR(13) + CHAR(10) +
                    STRING_AGG(
                        CONCAT(
                            SchemaName, '.', TableName, 
                            ' (Date Column: ', ISNULL(DateColumnName, 'None'), ')'
                        ),
                        CHAR(13) + CHAR(10)
                    )
                FROM dba.ExportConfig
                WHERE IsTransactionTable = 1;

                RAISERROR(@msg, 0, 1) WITH NOWAIT;
            END
        END

        -- Step 2: Analyze table relationships
        IF @Debug = 1 RAISERROR('Step 2: Analyzing table relationships...', 0, 1) WITH NOWAIT;
        
        EXEC dba.sp_AnalyzeTableRelationships
            @MaxRelationshipLevel = @MaxRelationshipLevel,
            @Debug = @Debug;

        IF @Debug = 1
        BEGIN
            SELECT @msg = 'Relationship summary:' + CHAR(13) + CHAR(10) +
                STRING_AGG(
                    CONCAT(
                        'Level ', RelationshipLevel, ': ',
                        COUNT(*), ' relationships'
                    ),
                    CHAR(13) + CHAR(10)
                )
            FROM dba.TableRelationships
            GROUP BY RelationshipLevel
            ORDER BY RelationshipLevel;

            RAISERROR(@msg, 0, 1) WITH NOWAIT;
        END

        -- Validate configuration
        IF NOT EXISTS (SELECT 1 FROM dba.ExportConfig WHERE IsTransactionTable = 1)
        BEGIN
            SET @ErrorMsg = 'No transaction tables identified. Please configure at least one transaction table.';
            THROW 50001, @ErrorMsg, 1;
        END

        -- Step 3: Build export tables
        IF @Debug = 1 RAISERROR('Step 3: Building export tables...', 0, 1) WITH NOWAIT;
        
        EXEC dba.sp_BuildExportTables
            @StartDate = @StartDate,
            @EndDate = @EndDate,
            @BatchSize = @BatchSize,
            @Debug = @Debug;

        SET @ExportID = SCOPE_IDENTITY();

        -- Step 4: Validate export tables
        IF @Debug = 1 RAISERROR('Step 4: Validating export tables...', 0, 1) WITH NOWAIT;
        
        EXEC dba.sp_ValidateExportTables
            @ExportID = @ExportID,
            @ThrowError = 1,
            @Debug = @Debug;

        -- Return export summary
        SELECT 
            el.ExportID,
            el.StartDate,
            el.EndDate,
            el.Status,
            el.RowsProcessed,
            JSON_QUERY(el.Parameters) as Parameters,
            DATEDIFF(SECOND, @StartTime, GETDATE()) as TotalProcessingSeconds,
            (
                SELECT 
                    SchemaName,
                    TableName,
                    RowsProcessed,
                    DATEDIFF(ms, StartTime, EndTime) / 1000.0 as ProcessingTimeSeconds
                FROM dba.ExportPerformance
                WHERE ExportID = el.ExportID
                FOR JSON PATH
            ) as TableDetails
        FROM dba.ExportLog el
        WHERE ExportID = @ExportID;

        IF @Debug = 1
        BEGIN
            SET @msg = CONCAT(
                'Export completed successfully', CHAR(13), CHAR(10),
                'Total time: ', DATEDIFF(SECOND, @StartTime, GETDATE()), ' seconds', CHAR(13), CHAR(10),
                'Export ID: ', @ExportID
            );
            RAISERROR(@msg, 0, 1) WITH NOWAIT;
        END
    END TRY
    BEGIN CATCH
        SET @ErrorMsg = ERROR_MESSAGE();
        
        -- Log error if we have an export ID
        IF @ExportID IS NOT NULL
        BEGIN
            UPDATE dba.ExportLog
            SET 
                EndDate = GETDATE(),
                Status = 'Failed',
                ErrorMessage = @ErrorMsg
            WHERE ExportID = @ExportID;
        END

        -- Re-throw error
        THROW;
    END CATCH
END;
GO

-- Example usage:
/*
-- Basic usage with default settings
EXEC dba.sp_ExportData 
    @StartDate = '2024-01-01',
    @EndDate = '2024-02-01';

-- Advanced usage with all options
EXEC dba.sp_ExportData 
    @StartDate = '2024-01-01',
    @EndDate = '2024-02-01',
    @AnalyzeStructure = 1,
    @MaxRelationshipLevel = 2,
    @MinimumRows = 5000,
    @ConfidenceThreshold = 0.8,
    @BatchSize = 50000,
    @Debug = 1;
*/
