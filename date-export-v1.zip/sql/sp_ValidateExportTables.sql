CREATE OR ALTER PROCEDURE dba.sp_ValidateExportTables
    @ExportID int,
    @ThrowError bit = 1,         -- Throw error on validation failure
    @Debug bit = 0               -- Enable debug output
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @SQL nvarchar(max);
    DECLARE @TableName nvarchar(128);
    DECLARE @SchemaName nvarchar(128);
    DECLARE @msg nvarchar(max);
    DECLARE @ValidationErrors TABLE (
        ErrorType varchar(50),
        SchemaName nvarchar(128),
        TableName nvarchar(128),
        Description nvarchar(max)
    );

    -- Validate export ID exists
    IF NOT EXISTS (SELECT 1 FROM dba.ExportLog WHERE ExportID = @ExportID)
        THROW 50001, 'Invalid Export ID', 1;

    -- Process each table in the database
    DECLARE table_cursor CURSOR FOR
    SELECT DISTINCT 
        t.name AS TableName,
        s.name AS SchemaName
    FROM sys.tables t
    INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
    WHERE t.is_ms_shipped = 0
    AND t.name NOT LIKE 'dba.%'
    ORDER BY s.name, t.name;

    OPEN table_cursor;
    FETCH NEXT FROM table_cursor INTO @TableName, @SchemaName;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @ExportTableName nvarchar(256) = QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName + '_Export');
        
        -- Check if export table exists
        IF OBJECT_ID(@ExportTableName, 'U') IS NULL
        BEGIN
            INSERT INTO @ValidationErrors (ErrorType, SchemaName, TableName, Description)
            VALUES ('Missing Table', @SchemaName, @TableName, 'Export table does not exist');
        END
        ELSE
        BEGIN
            -- Get primary key column
            DECLARE @PKColumn nvarchar(128);
            SELECT TOP 1 @PKColumn = c.name
            FROM sys.indexes i
            INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
            INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
            WHERE i.is_primary_key = 1
            AND i.object_id = OBJECT_ID(@SchemaName + '.' + @TableName);

            -- Validate relationship integrity
            IF EXISTS (
                SELECT 1 
                FROM dba.TableRelationships tr
                WHERE tr.ChildSchema = @SchemaName
                AND tr.ChildTable = @TableName
            )
            BEGIN
                -- Build validation query for each parent relationship
                DECLARE @ValidationSQL nvarchar(max) = N'
                SELECT @OrphanCount = COUNT(*)
                FROM ' + @ExportTableName + ' e
                INNER JOIN ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName) + ' t
                    ON t.' + QUOTENAME(@PKColumn) + ' = e.SourceID
                WHERE e.ExportID = @ExportID
                AND NOT EXISTS (';

                DECLARE @ParentChecks nvarchar(max) = '';
                
                SELECT @ParentChecks = STRING_AGG(
                    'SELECT 1 FROM ' + 
                    QUOTENAME(tr.ParentSchema) + '.' + 
                    QUOTENAME(tr.ParentTable + '_Export') + ' pe' +
                    CAST(ROW_NUMBER() OVER (ORDER BY tr.RelationshipLevel) AS varchar(10)) +
                    ' WHERE pe' + 
                    CAST(ROW_NUMBER() OVER (ORDER BY tr.RelationshipLevel) AS varchar(10)) +
                    '.ExportID = e.ExportID AND pe' +
                    CAST(ROW_NUMBER() OVER (ORDER BY tr.RelationshipLevel) AS varchar(10)) +
                    '.SourceID = t.' + fk.name,
                    ' UNION ALL '
                )
                FROM dba.TableRelationships tr
                INNER JOIN sys.foreign_keys fk ON 
                    fk.referenced_object_id = OBJECT_ID(tr.ParentSchema + '.' + tr.ParentTable)
                    AND fk.parent_object_id = OBJECT_ID(@SchemaName + '.' + @TableName)
                WHERE tr.ChildSchema = @SchemaName
                AND tr.ChildTable = @TableName;

                IF @ParentChecks IS NOT NULL
                BEGIN
                    SET @ValidationSQL = @ValidationSQL + @ParentChecks + ')';
                    
                    DECLARE @OrphanCount int;
                    EXEC sp_executesql @ValidationSQL, 
                        N'@ExportID int, @OrphanCount int OUTPUT',
                        @ExportID, @OrphanCount OUTPUT;

                    IF @OrphanCount > 0
                    BEGIN
                        INSERT INTO @ValidationErrors (ErrorType, SchemaName, TableName, Description)
                        VALUES (
                            'Orphaned Records', 
                            @SchemaName, 
                            @TableName, 
                            'Found ' + CAST(@OrphanCount AS varchar(20)) + ' records without parent references'
                        );
                    END
                END
            END

            -- Validate data consistency
            DECLARE @InvalidRecords int;
            SET @SQL = N'
            SELECT @InvalidRecords = COUNT(*)
            FROM ' + @ExportTableName + ' e
            WHERE e.ExportID = @ExportID
            AND NOT EXISTS (
                SELECT 1 
                FROM ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName) + ' t
                WHERE t.' + QUOTENAME(@PKColumn) + ' = e.SourceID
            )';

            EXEC sp_executesql @SQL,
                N'@ExportID int, @InvalidRecords int OUTPUT',
                @ExportID, @InvalidRecords OUTPUT;

            IF @InvalidRecords > 0
            BEGIN
                INSERT INTO @ValidationErrors (ErrorType, SchemaName, TableName, Description)
                VALUES (
                    'Invalid Records', 
                    @SchemaName, 
                    @TableName, 
                    'Found ' + CAST(@InvalidRecords AS varchar(20)) + ' records that do not exist in source table'
                );
            END
        END

        FETCH NEXT FROM table_cursor INTO @TableName, @SchemaName;
    END

    CLOSE table_cursor;
    DEALLOCATE table_cursor;

    -- Check for missing required tables
    INSERT INTO @ValidationErrors (ErrorType, SchemaName, TableName, Description)
    SELECT 
        'Required Table Missing',
        SchemaName,
        TableName,
        'Transaction table export is required but missing'
    FROM dba.ExportConfig ec
    WHERE ec.IsTransactionTable = 1
    AND NOT EXISTS (
        SELECT 1
        FROM sys.tables t
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.name = ec.TableName + '_Export'
        AND s.name = ec.SchemaName
    );

    -- Update export log with validation status
    UPDATE dba.ExportLog
    SET Status = CASE 
            WHEN EXISTS (SELECT 1 FROM @ValidationErrors) THEN 'Validation Failed'
            ELSE 'Validation Passed'
        END
    WHERE ExportID = @ExportID;

    -- Return validation results
    SELECT 
        ErrorType,
        SchemaName,
        TableName,
        Description
    FROM @ValidationErrors
    ORDER BY 
        CASE ErrorType
            WHEN 'Required Table Missing' THEN 1
            WHEN 'Missing Table' THEN 2
            WHEN 'Orphaned Records' THEN 3
            WHEN 'Invalid Records' THEN 4
            ELSE 5
        END,
        SchemaName,
        TableName;

    -- Throw error if validation failed and requested
    IF @ThrowError = 1 AND EXISTS (SELECT 1 FROM @ValidationErrors)
    BEGIN
        DECLARE @ErrorMsg nvarchar(max) = (
            SELECT STRING_AGG(
                CONCAT(
                    ErrorType, ': ',
                    SchemaName, '.', TableName,
                    ' - ', Description
                ),
                CHAR(13) + CHAR(10)
            )
            FROM @ValidationErrors
        );

        THROW 50002, @ErrorMsg, 1;
    END
END;
GO
