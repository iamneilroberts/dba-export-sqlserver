-- Test script for DateExport system
-- This script creates a sample database structure and demonstrates the export functionality

-- Create sample tables
CREATE TABLE dbo.Customers (
    CustomerID int IDENTITY(1,1) PRIMARY KEY,
    Name nvarchar(100),
    Email nvarchar(255),
    CreatedDate datetime DEFAULT GETDATE()
);

CREATE TABLE dbo.Orders (
    OrderID int IDENTITY(1,1) PRIMARY KEY,
    CustomerID int FOREIGN KEY REFERENCES dbo.Customers(CustomerID),
    OrderDate datetime DEFAULT GETDATE(),
    TotalAmount decimal(18,2)
);

CREATE TABLE dbo.OrderItems (
    OrderItemID int IDENTITY(1,1) PRIMARY KEY,
    OrderID int FOREIGN KEY REFERENCES dbo.Orders(OrderID),
    ProductName nvarchar(100),
    Quantity int,
    UnitPrice decimal(18,2)
);

CREATE TABLE dbo.CustomerNotes (
    NoteID int IDENTITY(1,1) PRIMARY KEY,
    CustomerID int FOREIGN KEY REFERENCES dbo.Customers(CustomerID),
    NoteDate datetime DEFAULT GETDATE(),
    Note nvarchar(max)
);

-- Insert sample data
-- Customers
INSERT INTO dbo.Customers (Name, Email, CreatedDate)
VALUES 
    ('John Doe', 'john@example.com', '2023-01-01'),
    ('Jane Smith', 'jane@example.com', '2023-01-15'),
    ('Bob Wilson', 'bob@example.com', '2023-02-01');

-- Orders
INSERT INTO dbo.Orders (CustomerID, OrderDate, TotalAmount)
VALUES
    (1, '2024-01-15', 100.00),
    (1, '2024-02-01', 150.00),
    (2, '2024-01-20', 200.00),
    (3, '2024-01-25', 75.00),
    (2, '2024-02-05', 300.00);

-- Order Items
INSERT INTO dbo.OrderItems (OrderID, ProductName, Quantity, UnitPrice)
VALUES
    (1, 'Widget A', 2, 50.00),
    (2, 'Widget B', 3, 50.00),
    (3, 'Widget C', 4, 50.00),
    (4, 'Widget A', 1, 75.00),
    (5, 'Widget B', 6, 50.00);

-- Customer Notes
INSERT INTO dbo.CustomerNotes (CustomerID, NoteDate, Note)
VALUES
    (1, '2024-01-15', 'First time customer'),
    (2, '2024-01-20', 'Preferred customer'),
    (3, '2024-01-25', 'Requires special handling');

-- Create indexes on date columns
CREATE INDEX IX_Orders_OrderDate ON dbo.Orders(OrderDate);
CREATE INDEX IX_CustomerNotes_NoteDate ON dbo.CustomerNotes(NoteDate);
GO

-- Example 1: Basic Usage
-- This example demonstrates the basic usage of the export system
PRINT 'Example 1: Basic Usage';
PRINT '--------------------';

-- First, let's manually configure a transaction table
INSERT INTO dba.ExportConfig (
    SchemaName,
    TableName,
    IsTransactionTable,
    DateColumnName,
    ForceFullExport
)
VALUES
    ('dbo', 'Orders', 1, 'OrderDate', 0);

-- Execute the export process
EXEC dba.sp_ExportData
    @StartDate = '2024-01-01',
    @EndDate = '2024-02-01',
    @Debug = 1;

-- Example 2: Automatic Analysis
-- This example demonstrates the automatic analysis features
PRINT 'Example 2: Automatic Analysis';
PRINT '-------------------------';

-- Clear previous configuration
DELETE FROM dba.ExportConfig;

-- Run export with automatic analysis
EXEC dba.sp_ExportData
    @StartDate = '2024-01-01',
    @EndDate = '2024-02-01',
    @AnalyzeStructure = 1,
    @MaxRelationshipLevel = 2,
    @MinimumRows = 1,  -- Lower threshold for test data
    @ConfidenceThreshold = 0.5,  -- Lower threshold for test data
    @Debug = 1;

-- Example 3: Manual Configuration
-- This example demonstrates how to manually configure the export system
PRINT 'Example 3: Manual Configuration';
PRINT '----------------------------';

-- Clear previous configuration
DELETE FROM dba.ExportConfig;

-- Configure tables manually
INSERT INTO dba.ExportConfig (
    SchemaName,
    TableName,
    IsTransactionTable,
    DateColumnName,
    ForceFullExport,
    BatchSize
)
VALUES
    ('dbo', 'Orders', 1, 'OrderDate', 0, 1000),
    ('dbo', 'CustomerNotes', 1, 'NoteDate', 0, 1000),
    ('dbo', 'Customers', 0, NULL, 1, 1000);  -- Force full export for Customers

-- Run export with manual configuration
EXEC dba.sp_ExportData
    @StartDate = '2024-01-01',
    @EndDate = '2024-02-01',
    @AnalyzeStructure = 0,  -- Skip analysis since we configured manually
    @Debug = 1;

-- Cleanup test data
/*
-- Uncomment to clean up test tables
DROP TABLE dbo.OrderItems;
DROP TABLE dbo.Orders;
DROP TABLE dbo.CustomerNotes;
DROP TABLE dbo.Customers;
*/

-- Query export results
SELECT 
    el.ExportID,
    el.StartDate,
    el.EndDate,
    el.Status,
    el.RowsProcessed,
    ep.TableName,
    ep.RowsProcessed as TableRows,
    DATEDIFF(ms, ep.StartTime, ep.EndTime) / 1000.0 as ProcessingSeconds
FROM dba.ExportLog el
INNER JOIN dba.ExportPerformance ep ON el.ExportID = ep.ExportID
ORDER BY el.ExportID DESC, ep.TableName;

-- Query relationship map
SELECT 
    ParentSchema,
    ParentTable,
    ChildSchema,
    ChildTable,
    RelationshipLevel,
    RelationshipPath
FROM dba.TableRelationships
ORDER BY RelationshipLevel, ParentSchema, ParentTable;
