CREATE OR ALTER PROCEDURE dba.sp_AnalyzeDatabaseStructure
    @MinimumRows int = 1000,              -- Minimum rows for transaction consideration
    @ConfidenceThreshold decimal(5,2) = 0.7,  -- Minimum confidence score (0-1)
    @Debug bit = 0                        -- Enable debug output
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @SQL nvarchar(max);
    DECLARE @TableName nvarchar(128);
    DECLARE @SchemaName nvarchar(128);
    DECLARE @msg nvarchar(max);

    -- Create temporary table to store analysis results
    CREATE TABLE #TableAnalysis (
        SchemaName nvarchar(128),
        TableName nvarchar(128),
        RowCount bigint,
        DateColumns nvarchar(max),         -- JSON array of date columns
        IndexedDateColumns nvarchar(max),  -- JSON array of indexed date columns
        TransactionConfidence decimal(5,2), -- Confidence score (0-1)
        ReasonCodes nvarchar(max),         -- JSON array of reason codes
        Analysis nvarchar(max)             -- Detailed analysis in JSON
    );

    -- Common transaction-related terms
    DECLARE @TransactionTerms TABLE (Term nvarchar(50));
    INSERT INTO @TransactionTerms (Term)
    VALUES 
        ('Transaction'),('Order'),('Invoice'),('Payment'),
        ('Registration'),('Visit'),('Estimate'),('Appointment'),
        ('Booking'),('Reservation'),('Entry'),('Event');

    -- Common date column names
    DECLARE @DateColumns TABLE (ColumnName nvarchar(50), Weight decimal(5,2));
    INSERT INTO @DateColumns (ColumnName, Weight)
    VALUES 
        ('TransactionDate', 1.0),
        ('OrderDate', 1.0),
        ('InvoiceDate', 1.0),
        ('PaymentDate', 1.0),
        ('VisitDate', 1.0),
        ('EventDate', 1.0),
        ('CreatedDate', 0.8),
        ('CreateDate', 0.8),
        ('ModifiedDate', 0.5),
        ('UpdatedDate', 0.5);

    -- Get all user tables with their row counts
    INSERT INTO #TableAnalysis (SchemaName, TableName, RowCount)
    SELECT 
        s.name AS SchemaName,
        t.name AS TableName,
        p.rows AS RowCount
    FROM sys.tables t
    INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
    INNER JOIN sys.indexes i ON t.object_id = i.object_id
    INNER JOIN sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
    WHERE 
        t.is_ms_shipped = 0
        AND i.index_id <= 1
        AND t.name NOT LIKE 'dba.%'; -- Exclude our own tables

    -- Analyze each table
    DECLARE table_cursor CURSOR FOR 
    SELECT SchemaName, TableName 
    FROM #TableAnalysis;

    OPEN table_cursor;
    FETCH NEXT FROM table_cursor INTO @SchemaName, @TableName;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @Confidence decimal(5,2) = 0;
        DECLARE @Reasons nvarchar(max) = '[]';
        DECLARE @DateColsJson nvarchar(max);
        DECLARE @IndexedDateColsJson nvarchar(max);
        DECLARE @Analysis nvarchar(max);

        -- Get date columns
        SET @SQL = N'
        SELECT @DateColsJson = (
            SELECT c.name AS columnName,
                   t.name AS dataType
            FROM sys.columns c
            INNER JOIN sys.types t ON c.system_type_id = t.system_type_id
            WHERE c.object_id = OBJECT_ID(@SchemaTable)
            AND t.name IN (''datetime'', ''datetime2'', ''date'')
            FOR JSON PATH
        )';

        SET @SQL = REPLACE(@SQL, '@SchemaTable', QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName));
        EXEC sp_executesql @SQL, N'@DateColsJson nvarchar(max) OUTPUT', @DateColsJson OUTPUT;

        -- Get indexed date columns
        SET @SQL = N'
        SELECT @IndexedDateColsJson = (
            SELECT DISTINCT c.name AS columnName
            FROM sys.indexes i
            INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
            INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
            INNER JOIN sys.types t ON c.system_type_id = t.system_type_id
            WHERE i.object_id = OBJECT_ID(@SchemaTable)
            AND t.name IN (''datetime'', ''datetime2'', ''date'')
            FOR JSON PATH
        )';

        SET @SQL = REPLACE(@SQL, '@SchemaTable', QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName));
        EXEC sp_executesql @SQL, N'@IndexedDateColsJson nvarchar(max) OUTPUT', @IndexedDateColsJson OUTPUT;

        -- Calculate confidence score based on multiple factors
        DECLARE @ReasonList TABLE (Reason nvarchar(max));

        -- Check table name for transaction terms
        SELECT @Confidence = @Confidence + 0.3
        FROM @TransactionTerms 
        WHERE @TableName LIKE '%' + Term + '%'
        AND NOT EXISTS (
            SELECT 1 FROM @ReasonList 
            WHERE Reason = 'NamePattern'
        );
        
        IF @Confidence > 0
            INSERT INTO @ReasonList VALUES ('NamePattern');

        -- Check for date columns with transaction-related names
        IF EXISTS (
            SELECT 1
            FROM @DateColumns dc
            CROSS APPLY OPENJSON(@DateColsJson)
            WITH (columnName nvarchar(128) '$.columnName')
            WHERE columnName LIKE '%' + dc.ColumnName + '%'
        )
        BEGIN
            SET @Confidence = @Confidence + 0.3;
            INSERT INTO @ReasonList VALUES ('DateColumnNames');
        END

        -- Check row count
        IF EXISTS (SELECT 1 FROM #TableAnalysis WHERE SchemaName = @SchemaName AND TableName = @TableName AND RowCount >= @MinimumRows)
        BEGIN
            SET @Confidence = @Confidence + 0.2;
            INSERT INTO @ReasonList VALUES ('RowCount');
        END

        -- Check for indexed date columns
        IF @IndexedDateColsJson IS NOT NULL
        BEGIN
            SET @Confidence = @Confidence + 0.2;
            INSERT INTO @ReasonList VALUES ('IndexedDates');
        END

        -- Build reason codes JSON
        SELECT @Reasons = (SELECT * FROM @ReasonList FOR JSON PATH);

        -- Build analysis JSON
        SET @Analysis = (
            SELECT 
                @Confidence AS confidence,
                JSON_QUERY(@Reasons) AS reasons,
                JSON_QUERY(@DateColsJson) AS dateColumns,
                JSON_QUERY(@IndexedDateColsJson) AS indexedDateColumns,
                RowCount AS rowCount
            FROM #TableAnalysis 
            WHERE SchemaName = @SchemaName 
            AND TableName = @TableName
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        -- Update analysis results
        UPDATE #TableAnalysis
        SET 
            DateColumns = @DateColsJson,
            IndexedDateColumns = @IndexedDateColsJson,
            TransactionConfidence = @Confidence,
            ReasonCodes = @Reasons,
            Analysis = @Analysis
        WHERE SchemaName = @SchemaName 
        AND TableName = @TableName;

        -- Debug output
        IF @Debug = 1
        BEGIN
            SET @msg = CONCAT(
                'Analyzed ', @SchemaName, '.', @TableName, CHAR(13), CHAR(10),
                'Confidence: ', @Confidence, CHAR(13), CHAR(10),
                'Analysis: ', @Analysis
            );
            RAISERROR(@msg, 0, 1) WITH NOWAIT;
        END

        DELETE FROM @ReasonList;
        FETCH NEXT FROM table_cursor INTO @SchemaName, @TableName;
    END

    CLOSE table_cursor;
    DEALLOCATE table_cursor;

    -- Insert results into ExportConfig for high-confidence tables
    INSERT INTO dba.ExportConfig (
        SchemaName, 
        TableName, 
        IsTransactionTable,
        DateColumnName
    )
    SELECT 
        t.SchemaName,
        t.TableName,
        1 AS IsTransactionTable,
        JSON_VALUE(t.IndexedDateColumns, '$[0].columnName') AS DateColumnName
    FROM #TableAnalysis t
    LEFT JOIN dba.ExportConfig e ON t.SchemaName = e.SchemaName AND t.TableName = e.TableName
    WHERE 
        t.TransactionConfidence >= @ConfidenceThreshold
        AND e.ConfigID IS NULL -- Don't insert if already exists
        AND t.IndexedDateColumns IS NOT NULL;

    -- Return analysis results
    SELECT 
        SchemaName,
        TableName,
        RowCount,
        TransactionConfidence,
        DateColumns,
        IndexedDateColumns,
        ReasonCodes,
        Analysis,
        CASE 
            WHEN TransactionConfidence >= @ConfidenceThreshold THEN 'Suggested Transaction Table'
            WHEN TransactionConfidence >= @ConfidenceThreshold * 0.7 THEN 'Possible Transaction Table'
            ELSE 'Likely Not Transaction Table'
        END AS Recommendation
    FROM #TableAnalysis
    WHERE TransactionConfidence > 0
    ORDER BY TransactionConfidence DESC;

    DROP TABLE #TableAnalysis;
END;
GO
