CREATE OR ALTER PROCEDURE dba.sp_BuildExportTables
    @StartDate datetime,
    @EndDate datetime = NULL,
    @DropExisting bit = 1,           -- Drop existing export tables
    @BatchSize int = 10000,          -- Default batch size for processing
    @Debug bit = 0                   -- Enable debug output
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @SQL nvarchar(max);
    DECLARE @TableName nvarchar(128);
    DECLARE @SchemaName nvarchar(128);
    DECLARE @msg nvarchar(max);
    DECLARE @ExportID int;
    DECLARE @DateColumn nvarchar(128);
    DECLARE @BatchStart datetime = GETDATE();
    DECLARE @RowsProcessed int = 0;

    -- Validate parameters
    IF @StartDate IS NULL
        THROW 50001, 'Start date must be provided', 1;
    
    IF @EndDate IS NULL
        SET @EndDate = GETDATE();

    IF @StartDate > @EndDate
        THROW 50002, 'Start date must be before end date', 1;

    -- Start new export operation
    INSERT INTO dba.ExportLog (
        StartDate, 
        Status, 
        Parameters
    )
    SELECT 
        GETDATE(),
        'Started',
        (
            SELECT 
                @StartDate as startDate,
                @EndDate as endDate,
                @BatchSize as batchSize
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
    
    SET @ExportID = SCOPE_IDENTITY();

    BEGIN TRY
        -- Process each table in the database
        DECLARE table_cursor CURSOR FOR
        SELECT DISTINCT 
            t.name AS TableName,
            s.name AS SchemaName
        FROM sys.tables t
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.is_ms_shipped = 0
        AND t.name NOT LIKE 'dba.%'
        ORDER BY s.name, t.name;

        OPEN table_cursor;
        FETCH NEXT FROM table_cursor INTO @TableName, @SchemaName;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @ExportTableName nvarchar(256) = QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName + '_Export');
            DECLARE @IsTransactionTable bit;
            DECLARE @ForceFullExport bit;
            
            -- Get configuration for current table
            SELECT 
                @IsTransactionTable = IsTransactionTable,
                @ForceFullExport = ForceFullExport,
                @DateColumn = DateColumnName
            FROM dba.ExportConfig 
            WHERE SchemaName = @SchemaName 
            AND TableName = @TableName;

            -- Drop existing export table if requested
            IF @DropExisting = 1
            BEGIN
                SET @SQL = N'IF OBJECT_ID(''' + @ExportTableName + ''', ''U'') IS NOT NULL 
                            DROP TABLE ' + @ExportTableName;
                EXEC sp_executesql @SQL;
            END

            -- Create export table
            SET @SQL = N'
            CREATE TABLE ' + @ExportTableName + ' (
                ExportID int NOT NULL,
                SourceID sql_variant NOT NULL,
                DateAdded datetime NOT NULL DEFAULT GETDATE(),
                CONSTRAINT PK_' + @TableName + '_Export PRIMARY KEY (ExportID, SourceID)
            )';
            
            EXEC sp_executesql @SQL;

            -- Initialize performance tracking
            INSERT INTO dba.ExportPerformance (
                ExportID,
                TableName,
                SchemaName,
                StartTime
            )
            VALUES (
                @ExportID,
                @TableName,
                @SchemaName,
                GETDATE()
            );

            -- Get primary key column
            DECLARE @PKColumn nvarchar(128);
            SELECT TOP 1 @PKColumn = c.name
            FROM sys.indexes i
            INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
            INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
            WHERE i.is_primary_key = 1
            AND i.object_id = OBJECT_ID(@SchemaName + '.' + @TableName);

            IF @PKColumn IS NULL
                THROW 50003, 'Table must have a primary key', 1;

            -- Build insert statement based on table type
            IF @IsTransactionTable = 1 AND @DateColumn IS NOT NULL
            BEGIN
                -- Transaction table with date column
                SET @SQL = N'
                INSERT INTO ' + @ExportTableName + ' (ExportID, SourceID)
                SELECT 
                    @ExportID,
                    ' + QUOTENAME(@PKColumn) + '
                FROM ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName) + '
                WHERE ' + QUOTENAME(@DateColumn) + ' >= @StartDate
                AND ' + QUOTENAME(@DateColumn) + ' <= @EndDate';
            END
            ELSE IF EXISTS (
                -- Child table of transaction table
                SELECT 1 
                FROM dba.TableRelationships tr
                INNER JOIN dba.ExportConfig ec 
                    ON tr.ParentSchema = ec.SchemaName 
                    AND tr.ParentTable = ec.TableName
                WHERE tr.ChildSchema = @SchemaName
                AND tr.ChildTable = @TableName
                AND ec.IsTransactionTable = 1
            )
            BEGIN
                -- Get all parent relationships
                DECLARE @ParentJoins nvarchar(max) = '';
                
                SELECT @ParentJoins = STRING_AGG(
                    'INNER JOIN ' + QUOTENAME(tr.ParentSchema) + '.' + tr.ParentTable + '_Export pe' + 
                    CAST(ROW_NUMBER() OVER (ORDER BY tr.RelationshipLevel) AS varchar(10)) +
                    ' ON pe' + CAST(ROW_NUMBER() OVER (ORDER BY tr.RelationshipLevel) AS varchar(10)) +
                    '.SourceID = t.' + fk.name,
                    ' '
                )
                FROM dba.TableRelationships tr
                INNER JOIN sys.foreign_keys fk ON 
                    fk.referenced_object_id = OBJECT_ID(tr.ParentSchema + '.' + tr.ParentTable)
                    AND fk.parent_object_id = OBJECT_ID(@SchemaName + '.' + @TableName)
                INNER JOIN dba.ExportConfig ec 
                    ON tr.ParentSchema = ec.SchemaName 
                    AND tr.ParentTable = ec.TableName
                WHERE tr.ChildSchema = @SchemaName
                AND tr.ChildTable = @TableName
                AND ec.IsTransactionTable = 1;

                SET @SQL = N'
                INSERT INTO ' + @ExportTableName + ' (ExportID, SourceID)
                SELECT DISTINCT
                    @ExportID,
                    t.' + QUOTENAME(@PKColumn) + '
                FROM ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName) + ' t
                ' + @ParentJoins + '
                WHERE 1=1';
            END
            ELSE IF @ForceFullExport = 1 OR NOT EXISTS (
                -- Not related to any transaction table
                SELECT 1 
                FROM dba.TableRelationships tr
                WHERE (tr.ChildSchema = @SchemaName AND tr.ChildTable = @TableName)
                OR (tr.ParentSchema = @SchemaName AND tr.ParentTable = @TableName)
            )
            BEGIN
                -- Full table export
                SET @SQL = N'
                INSERT INTO ' + @ExportTableName + ' (ExportID, SourceID)
                SELECT 
                    @ExportID,
                    ' + QUOTENAME(@PKColumn) + '
                FROM ' + QUOTENAME(@SchemaName) + '.' + QUOTENAME(@TableName);
            END

            IF @SQL IS NOT NULL
            BEGIN
                -- Execute insert with batching
                SET @SQL = N'
                DECLARE @BatchStart sql_variant;
                WHILE 1=1
                BEGIN
                    ' + @SQL + '
                    AND (@BatchStart IS NULL OR ' + QUOTENAME(@PKColumn) + ' > @BatchStart)
                    ORDER BY ' + QUOTENAME(@PKColumn) + '
                    OFFSET 0 ROWS
                    FETCH NEXT @BatchSize ROWS ONLY;

                    SET @RowCount = @@ROWCOUNT;
                    IF @RowCount = 0 BREAK;

                    SET @BatchStart = (
                        SELECT MAX(SourceID)
                        FROM ' + @ExportTableName + '
                        WHERE ExportID = @ExportID
                    );
                END';

                DECLARE @RowCount int;
                EXEC sp_executesql @SQL,
                    N'@ExportID int, @StartDate datetime, @EndDate datetime, @BatchSize int, @RowCount int OUTPUT',
                    @ExportID, @StartDate, @EndDate, @BatchSize, @RowCount OUTPUT;

                -- Update performance metrics
                UPDATE dba.ExportPerformance
                SET 
                    EndTime = GETDATE(),
                    RowsProcessed = (
                        SELECT COUNT(*)
                        FROM dba.TableRelationships tr
                        WHERE tr.ChildSchema = @SchemaName
                        AND tr.ChildTable = @TableName
                    )
                WHERE 
                    ExportID = @ExportID
                    AND TableName = @TableName
                    AND SchemaName = @SchemaName;

                IF @Debug = 1
                BEGIN
                    SET @msg = CONCAT(
                        'Processed ', @SchemaName, '.', @TableName, CHAR(13), CHAR(10),
                        'Rows: ', @RowCount, CHAR(13), CHAR(10),
                        'Time: ', DATEDIFF(ms, @BatchStart, GETDATE()) / 1000.0, ' seconds'
                    );
                    RAISERROR(@msg, 0, 1) WITH NOWAIT;
                END
            END

            SET @BatchStart = GETDATE();
            FETCH NEXT FROM table_cursor INTO @TableName, @SchemaName;
        END

        CLOSE table_cursor;
        DEALLOCATE table_cursor;

        -- Update export log
        UPDATE dba.ExportLog
        SET 
            EndDate = GETDATE(),
            Status = 'Completed',
            RowsProcessed = (
                SELECT SUM(RowsProcessed)
                FROM dba.ExportPerformance
                WHERE ExportID = @ExportID
            )
        WHERE ExportID = @ExportID;

        -- Return summary
        SELECT 
            el.ExportID,
            el.StartDate,
            el.EndDate,
            el.Status,
            el.RowsProcessed,
            JSON_QUERY(el.Parameters) as Parameters,
            (
                SELECT 
                    SchemaName,
                    TableName,
                    RowsProcessed,
                    DATEDIFF(ms, StartTime, EndTime) / 1000.0 as ProcessingTimeSeconds
                FROM dba.ExportPerformance
                WHERE ExportID = el.ExportID
                FOR JSON PATH
            ) as TableDetails
        FROM dba.ExportLog el
        WHERE ExportID = @ExportID;
    END TRY
    BEGIN CATCH
        -- Log error and rethrow
        UPDATE dba.ExportLog
        SET 
            EndDate = GETDATE(),
            Status = 'Failed',
            ErrorMessage = ERROR_MESSAGE()
        WHERE ExportID = @ExportID;

        THROW;
    END CATCH
END;
GO
